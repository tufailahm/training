package demos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Types;

import com.revature.pms.util.DBConnection;

public class CallingProcedure_TransferWithOut {

	public static void main(String[] args) throws SQLException {
		
		Connection connection = DBConnection.getDBConnection();
		int bal1=0;
		int bal2=0;
		CallableStatement stat = connection.prepareCall("call hr.transferAmountAndGetbalance(?,?,?,?,?)");
		stat.setInt(1, 1);
		stat.setInt(2, 2);
		stat.setInt(3, 100);
		stat.registerOutParameter(4, Types.INTEGER);
		stat.setInt(4, bal1);
		stat.registerOutParameter(5, Types.INTEGER);
		stat.setInt(5, bal2);

		stat.execute();
		
		bal1 = stat.getInt(4);
		bal2 = stat.getInt(5);
		
		System.out.println(bal1);
		System.out.println(bal2);
		System.out.println("Done");
		
	}
}
