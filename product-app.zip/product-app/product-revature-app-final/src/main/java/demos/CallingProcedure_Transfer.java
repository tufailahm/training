package demos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.revature.pms.util.DBConnection;

public class CallingProcedure_Transfer {

	public static void main(String[] args) throws SQLException {
		
		Connection connection = DBConnection.getDBConnection();
		
		CallableStatement stat = connection.prepareCall("call hr.transferAmount(?,?,?)");
		stat.setInt(1, 1);
		stat.setInt(2, 2);
		stat.setInt(3, 500);
		
		stat.execute();
		
		System.out.println("Stored procedure executed successfully!!");
		
	}
}
