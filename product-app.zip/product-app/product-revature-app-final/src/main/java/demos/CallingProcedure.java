package demos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.revature.pms.util.DBConnection;

public class CallingProcedure {

	public static void main(String[] args) throws SQLException {
		
		Connection connection = DBConnection.getDBConnection();
		
		CallableStatement stat = connection.prepareCall("call hr.ADD_ACCOUNTS(?,?,?)");
		stat.setInt(1, 190);
		stat.setString(2, "Arun");
		stat.setFloat(3, 98000);
		
		stat.execute();
		
		System.out.println("Done");
		
	}
}
