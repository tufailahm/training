package iodemos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerlizationDemo_ToRead {

	public static void main(String[] args) {
		readPatientFromFile();
	}

	private static void readPatientFromFile() {

		System.out.println("#################Object reading program");
		Patient patient = new Patient();

		try {
			ObjectInputStream out = new ObjectInputStream
					(new FileInputStream(new File("h:\\patients2.csv")));
			patient = (Patient) out.readObject();
			System.out.println("The patient details from the file is :");
			System.out.println(patient);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
