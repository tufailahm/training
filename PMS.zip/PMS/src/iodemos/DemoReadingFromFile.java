package iodemos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DemoReadingFromFile {

	public static void main(String[] args) {
		
		readFromFile();
	}

	private static void readFromFile() {
		FileInputStream reader=null;
		try {
			File file = new File("h://about.txt");
			if(file.exists()) {
			 reader= new FileInputStream(file);
				int i=0;
				while( (i = reader.read()) != -1)
				{
					System.out.print((char)i);
				}
			}
			else
			{
				System.out.println("File does not exists");
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
