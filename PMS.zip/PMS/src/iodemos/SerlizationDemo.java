package iodemos;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerlizationDemo {

	
	public static void main(String[] args) {
		writePatientToFile();
	}

	private static void writePatientToFile() {
		
		System.out.println("#################Object savings program");
		Patient patient =new Patient(121,"Neha",900,"Kalpana");
		
		try {
			ObjectOutputStream out = new ObjectOutputStream
					(new FileOutputStream(new File("h:\\patients2.csv")));
			out.writeObject(patient);
			System.out.println("##Patient detail saved");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
