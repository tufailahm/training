package iodemos;

import java.io.FileWriter;
import java.io.IOException;

public class DemoWritingToFile {

	public static void writeToFile() {
		//ask user to enter some quotes
		//save this quotes in a file.
		
		try {
			FileWriter fw = new FileWriter("h:\\revature.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		
		writeToFile();
	}
}
