package iodemos;

import java.io.File;
import java.io.IOException;

public class Demo1 {

	public static void main(String[] args) {
		
		File file = new File("h://records.txt");
		
		if(file.exists())
		{
			file.delete();
			System.out.println("File exists and deleted");
		}
		else
		{
			try {
				file.createNewFile();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("File doesn't exist and created");
		}
	}
}
