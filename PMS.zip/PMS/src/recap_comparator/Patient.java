package recap_comparator;

public class Patient implements Comparable<Patient> {
	private int patientId;
	private String patientName;
	private int billAmount;
	private String doctorName;

	public Patient() {
	}

	public Patient(int patientId, String patientName, int billAmount, String doctorName) {
		this.patientId = patientId;
		this.patientName = patientName;
		this.billAmount = billAmount;
		this.doctorName = doctorName;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	@Override
	public String toString() {
		return "\nPatient [patientId=" + patientId + ", patientName=" + patientName + ", billAmount=" + billAmount
				+ ", doctorName=" + doctorName + "]";
	}

	@Override
		public int compareTo(Patient o) {
			
			if(o.getDoctorName().compareTo(this.getDoctorName()) >0)
			return -1;
			else
				return 1;
		}

}
