package recap_comparator;

import java.util.Comparator;

public class PatientNameComparator implements Comparator<Patient> {

	@Override
	public int compare(Patient o1, Patient o2) {
		if (o1.getPatientName().compareTo(o2.getPatientName()) > 0)
			return 1;
		else
			return -1;
	}

}
