package scopes;

//local , instance and static variable
public class DemoStatic {

	int num1 = 100; // instance variable
	int num2 = 200; // instance variable

	public void display() {
		num1 = 0;
		int num2 = 0; // local variable
		//
		
	}

	public static void main(String[] args) {
		DemoStatic d = new DemoStatic();
		d.display();
	}
}
