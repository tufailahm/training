package scopes;

//local , instance and static variable
//Each and every object will have separate copy of instance variable
public class DemoStatic {

	int num1 = 100; // instance variable
	static int num2 = 200; // class variable

	public DemoStatic() {
		num1 = num2++;
	}
	public void display() {
		System.out.println("Num 1 :"+num1);
		System.out.println("Num 2 :"+num2);
	}
	public void changeNumber() {
		num2 = --num1;
		System.out.println("Change number called");
	}
	public static void changeData() {
			num2=1;
			System.out.println("Change data - static  called");
	}

	public static void main(String[] args) {
		DemoStatic d1 = new DemoStatic();
		DemoStatic d2 = new DemoStatic();

		d1.changeNumber();
		
		d1.display();
		d2.display();
		
		changeData();

	}
}
