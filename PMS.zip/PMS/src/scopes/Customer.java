package scopes;

public class Customer {

	int num1 = 100;
	static int num2=20;
	//anonymous block
	{
		System.out.println("2");
	}

	static
	{
		System.out.println("5");
	}
	public void display() {
		System.out.println("1");
	}

	public Customer() {
		System.out.println("4");
	}

	public static void main(String[] args) {
		System.out.println("3");
		Customer customer = new Customer();
	}
}