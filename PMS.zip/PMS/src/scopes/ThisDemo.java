package scopes;

public class ThisDemo {

	int age = 100;

	public void display(int age) {

		this.age = age;
	}

	public static void main(String[] args) {

		ThisDemo d = new ThisDemo();
		d.display(99);
	}
}

