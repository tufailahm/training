package scopes;

//local and instance variable
public class Demo {

	int num1 = 0; // instance variable

	public void display() {
		num1 = 0;
		int num2;// local variable
		//
		if (num1 == 0);
			num2 = 29;
		System.out.println(num1 + num2 + 20);
	}
	public static void main(int num) {
		Demo d = new Demo();
		d.display();
	}
	
	public static void main(String[] args) {
		Demo d = new Demo();
		d.display();
	}
}
