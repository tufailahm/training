package scopes;

class Employee
{
	static int count=0;
	public void objectAdded(){
		count++;
	}
}
public class CountOfObjects {

	public static void main(String[] args) {
		
		Employee employee1 = new Employee();
		employee1.objectAdded();
		Employee employee2 = new Employee();
		employee2.objectAdded();
		Employee employee3 = new Employee();
		employee3.objectAdded();
		
		System.out.println(employee3.count);
	}
}
