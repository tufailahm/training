package wrapperdemo;

public class Demo {

	
	public static void main(String[] args) {
		
		String scores="90";
		
		int marks = Integer.parseInt(scores);
		System.out.println(marks+5);
		
		Integer pp = 199;
		int i = pp;		//auto unboxing - object to  primitive data is known as auto-unboxing 
		
		Integer jj = i;	//autoboxing - primitive data types into its equivalent Wrapper type is known as auto-boxing 
	}
}
