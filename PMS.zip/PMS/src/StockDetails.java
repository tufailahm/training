
public class StockDetails {
	public void outOfStock() {
		System.out.println("####Sorry, the product is out of stock");
	}
}
