package inheritance;

public class Pedigree extends Meal {

}
