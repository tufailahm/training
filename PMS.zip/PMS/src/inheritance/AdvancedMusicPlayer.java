package inheritance;

public interface AdvancedMusicPlayer extends MusicPlayer{
		void startMusicPlayerByBlueTooth();
}
