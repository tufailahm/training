package inheritance;

/** Testing application */
public class Test {

	public static void main(String str[]) {
		System.out.print("Hello");
	}
}
