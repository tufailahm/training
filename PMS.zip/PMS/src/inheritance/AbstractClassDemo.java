package inheritance;

abstract class Vehicle {
	int price = 0;

	public void service() {
		System.out.println("##Vehicle Serviced!!");
	}

	public abstract void start();

	public abstract void stop();
}

abstract class Car extends Vehicle {

	@Override
	public void start() {
		System.out.println("Car started successfully");

	}
	public abstract void playMusic();
}
class Santro extends Car implements AdvancedMusicPlayer, AirConditioner
{

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void playMusic() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startAC() {
		System.out.println("AC started at temperature :"+initialTemp);
		
	}

	@Override
	public void loadMusic() {
		System.out.println("Music player price :"+MusicPlayer.price);
		
	}

	@Override
	public void startMusicPlayerByBlueTooth() {
		// TODO Auto-generated method stub
		
	}
	
}


class Bike {

}

public class AbstractClassDemo {

	public static void main(String[] args) {
		Santro  s = new Santro();
		s.start();
		s.stop();
		s.service();
		s.loadMusic();
		s.startAC();
		
	}
}
