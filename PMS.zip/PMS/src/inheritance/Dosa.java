package inheritance;

public class Dosa extends Meal{

}
