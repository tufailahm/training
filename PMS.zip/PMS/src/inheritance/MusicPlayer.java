package inheritance;

public interface MusicPlayer {
		int price=9000;
		void loadMusic();
}
