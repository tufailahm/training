package inheritance;

class Tea
{
	
}
class Teacher extends Tea
{
	
}
public class Demo2 {

	public static void main(String[] args) {
		
	}
}
