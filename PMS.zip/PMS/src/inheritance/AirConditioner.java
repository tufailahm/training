package inheritance;

public interface AirConditioner {
		public  final static int initialTemp=20;
		public abstract void startAC();
}
 