package inheritance;

class Animal extends Object {
	int age = 100;
	int height;

	public Meal eat() {
		System.out.println("Animal eats");
		return null;
	}
}

class Cat extends Animal {
	

}


class Men extends Animal {
	int age = 90; // allowed but not recommended
	String name;
	Address address;

	// allowed, recommended and overriding
	@Override
	public Dosa eat() {
		System.out.println("Men eat veg and non-veg");
		return null;
	}

	public void dd() {
		
	}
}

class Dog extends Animal {
	String gener;

	public Pedigree eat() {
		System.out.println("Dog eats pedigree");
		return null;
	}
}

class Address {
	int addressId;
	String city;
	String state;
	String pinCode;
}

public class Demo {

	public static void main(String[] args) {
		System.out.println("1 - no object is eligible for GC");
		Men m = new Men();
		m.eat();

		Dog d = new Dog();
		d.eat();

		System.out.println("2");
		Animal a = new Men();
		a.eat();
		a = new Dog();
		a.eat();
	}
}
