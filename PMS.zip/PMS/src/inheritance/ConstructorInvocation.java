package inheritance;

class ElectronicDevice
{
	final int PRICE;
	public ElectronicDevice() {
		System.out.println("Electronic cons - 1");
		PRICE=98000;

	}
	public ElectronicDevice(String name) {
		PRICE=88000;
		System.out.println("Electronic cons - 2");

	}
	public void start() {
	}
}
class Mobile extends ElectronicDevice{

	public Mobile() {
		super();
		System.out.println("Mobile cons - 1");

	}
	public Mobile(String name) {
		super(name);
		System.out.println("Mobile cons - 2");

	}
	
	public void start() {
		System.out.println();
		super.start();
	}

}
public class ConstructorInvocation {

	public static void main(String[] args) {
		Mobile mobile = new Mobile("iPhone");
		System.out.println(mobile.PRICE);
	}
}
