package inheritance;

public class Meal {

}
