package com.oracle.springtraining.coupling1.interfacesolutions;

public class IssueChequeService {
		
}
