package com.oracle.springtraining.coupling1.factorysolution;

public class IssueChequeService {

	private Account account;
	
	public IssueChequeService(String accType) {
		account = new AccountFactory().manufactureAccount(accType);
	}
}
