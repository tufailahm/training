package com.oracle.springtraining.coupling1;

public class LoanAccount {

	private String accountNumber;
	public LoanAccount(String accountNUmber) {
		this.accountNumber = accountNUmber;
	}
	public String getDetails(){
		return accountNumber;
	}
}
