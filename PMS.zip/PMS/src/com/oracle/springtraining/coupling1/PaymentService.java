package com.oracle.springtraining.coupling1;

public class PaymentService {
	
	private SavingsAccount savingsAccount;
	private CurrentAccount currentAccount;
	
	public PaymentService(String accType) {
		if(accType.equals("S"))
			savingsAccount = new SavingsAccount("98715252323");
		else if(accType.equals("C"))
			currentAccount = new CurrentAccount("11212");
			
	}
	public void pay(){
	
		System.out.println("Payment  ->  "+ this.savingsAccount.getDetails());
	}
}
