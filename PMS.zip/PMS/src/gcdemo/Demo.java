package gcdemo;

class Employee {

	protected void finalize() {
		System.out.println("Finalize called");

	}
}

public class Demo {

	public static void main(String[] args) {

		Employee e1 = new Employee();
		Employee e2 = new Employee();
		Employee e3 = new Employee();
		Employee e4 = e2;
		e2 = null;
		e1 = e2;
		e4= null;
		
		System.gc(); // To invoke GC
		System.out.println("Thanks");
	}
}
