import finance.currentyear.trainees.*;

import finance.currentyear.trainees.Employee;

import payment.Bill;
import java.lang.System;
import java.util.Date;
import java.lang.String;


public class Welcome {

	String employeeName = "Naveen Tyagi";

	@Deprecated
	public Welcome() {
		// TODO Auto-generated constructor stub
	}
	@Deprecated
	public void messageFromCEO() {
		System.out.println("3. Good Luck for your training  " + employeeName);
	}

	
	public void printMessage() {
		System.out.println("2. This is print message - Message from a method - START");
		Welcome w = new Welcome();
		w.messageFromCEO();
		System.out.println("4. This is print message - Message from a method - END");

	}

	public static void main(String[] args) {
		
		Date d = new Date("12/09/2020");
		System.out.println(d);
		System.out.println("1. Hi I my name is Tufail Ahmed");
		Welcome w = new Welcome();
		w.printMessage();
		System.out.println("5. Welcome to Revature..");

		System.out.println("Opening the product app");
		ProductApp productApp = new ProductApp();
		productApp.openProductApp();

		OrderDetails orderDetails = new OrderDetails();
		orderDetails.orderSuccess();

		finance.Employee employee = new finance.Employee();
		employee.allocateProject();

		Bill bill = new Bill();
		bill.payBill();
	}
}

class ProductApp {
	public void openProductApp() {
		System.out.println("Opening product app");
	}

	public static void main(String[] args) {
		System.out.println("I am Product App Main");
	}
}

class EmployeeApp {
	public void openEmployeeApp() {
		System.out.println("Opening employee  app");
	}
}