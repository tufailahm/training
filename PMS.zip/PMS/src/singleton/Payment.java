package singleton;

//singleton design pattern - creational
class Payment
{
	private static Payment  payment;
	//step 1 : make cons private
	private Payment() {
		System.out.println("###Payment object created");
	}
	
	//step 2
	public static Payment getPaymentObject() {
		if(payment == null)
		{
			payment = new Payment();
		}
		
		return payment;
	}
	public void withdraw(int amount)
	{
		System.out.println(amount + " INR , Debited");
	}
}
