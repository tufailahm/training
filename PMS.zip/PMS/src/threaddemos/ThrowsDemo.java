package threaddemos;

public class ThrowsDemo {

	public void display1() throws InterruptedException {
		System.out.println("Hello from display1");
		Thread.sleep(2000);
		System.out.println("Hello from display2");

	}
	public void display2() {
		System.out.println("Hello from display2");
		try {
			int num=100/0;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Hello from display2");

	}
	public static void main(String[] args) throws InterruptedException {
		System.out.println("MAIN - HELLO");
		ThrowsDemo demo = new ThrowsDemo();
		demo.display1();
		demo.display2();
		System.out.println("MAIN - BYE");
	}
}
