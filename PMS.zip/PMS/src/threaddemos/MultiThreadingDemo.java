package threaddemos;

class Games extends Thread
{
	
	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("RUN CALLED BY :"+ Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	
	}
}
public class MultiThreadingDemo {

	public static void main(String[] args) {
		Thread.currentThread().setName("TUFAILAHMED");
		System.out.println("MAIN CALLED BY :"+ Thread.currentThread().getName());

		Games g1 = new Games();
		g1.setName("SCORES");
		g1.start();
		
		
		Games g2 = new Games();
		g2.setName("SOUND");
		g2.start();
	}
}
