package threaddemos;


public class DemoThreadfAnonymous {

	public static void main(String[] args) {
		
		System.out.println("MAIN CALLED BY :"+ Thread.currentThread().getName());
		
		Thread t1 = new Thread()
		{
				@Override
				public void run() {
					System.out.println("RUN CALLED BY :"+ Thread.currentThread().getName());
				}
		};
		
		t1.start();
	}
}
