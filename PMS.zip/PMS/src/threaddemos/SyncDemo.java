package threaddemos;

class WelcomeGuest {

	// thread safe --sync
	public static synchronized void printMessage(String firstName, String lastName) {
		System.out.println("Welcome to Taj Hotel");
		System.out.println("Mr/Ms. " + firstName);
		// storing the data in db
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(lastName);
		System.out.println("Thanks for visiting my hotel , "+firstName);

	}
}
class Hotel extends Thread {
	String fn, ln;

	public Hotel() {
	}

	public Hotel(String fn, String ln) {
		this.fn = fn;
		this.ln = ln;
	}

	@Override
	public void run() {
		WelcomeGuest.printMessage(fn, ln);
	}
}
public class SyncDemo {

	public static void main(String[] args) {

		Hotel hotel1 = new Hotel("Tufail", "Ahmed");
		hotel1.start();
		Hotel hotel2 = new Hotel("Neha", "Agrawal");
		hotel2.start();
		Hotel hotel3 = new Hotel("Ravi", "Saxena");
		hotel3.start();
	}
}
