package threaddemos;

//TWO THREADS
public class Demo extends Thread {
	Thread t1;

	public Demo() {
		t1 = new Thread(this);		//child thread
		t1.start();
	}

	@Override
	public void run() 
	{
		System.out.println("RUN CALLED   "+ Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		new Demo();		//creates a main thread
		System.out.println("inside MAIN CALLED   "+ Thread.currentThread().getName());
	}
}

//1%
//RUN CALLED
//MAIN CALLED


//99%
//MAIN CALLED
//RUN CALLED