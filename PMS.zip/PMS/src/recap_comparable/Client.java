package recap_comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Client {

	public static void main(String[] args) {

		List<Patient> patients = new ArrayList<Patient>();
		patients.add(new Patient(1, "Neha", 12000, "Jay"));
		patients.add(new Patient(2, "Arun", 18000, "Veeru"));
		patients.add(new Patient(3, "Mohan", 2000, "Gabbar"));
		patients.add(new Patient(4, "Zeba", 17500, "Sambha"));
		patients.add(new Patient(5, "Yamini", 15400, "Thakur"));

		System.out.println(patients);

		System.out.println("Sort by Bill Amount : ");

		Collections.sort(patients, new Comparator<Patient>() {

			@Override
			public int compare(Patient o1, Patient o2) {

				if (o1.getBillAmount() > o2.getBillAmount())
					return -1;
				else
					return 1;
			}
		});

		System.out.println(patients);

		// Default sorting for patient - based on Doctor Name
		Collections.sort(patients);
		System.out.println(patients);

		// Default sorting for patient - based on Patient Name
		Collections.sort(patients);
		System.out.println(patients);

	}

}
