package finance.currentyear.trainees;

public class Employee {
	public void training() {
		System.out.println("Employee training going on");
	}
}
