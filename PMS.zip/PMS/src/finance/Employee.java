package finance;

public class Employee {
		public void allocateProject() {
			System.out.println("Employee - Project allocation done");
		}
}
