
public class OrderDetails {

	public void orderSuccess() {
		System.out.println("####Congratulations, you have successfully placed an order");
	}
}
