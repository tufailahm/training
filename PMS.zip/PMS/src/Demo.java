import java.lang.System;

public class Demo {

	long p = 109;
	int l = (int) p;

	
	byte marks = (byte) 130;	
	float engMarks = (float) 19.5;

	short k = 19;	//implicit casting
	public void display() {
		System.out.println(engMarks + 10);
		System.out.println("Marks is :" + marks);
		
		byte i=10;	//iM
		byte j=20;//IM
		int k = i;	//IM
		
		int p=100;
		byte pp = (byte) p;	//EX

		 int rt = 19;
			//1		4
		byte jt=(byte) rt;		//IM
		
	}

	static public void main(String args[]) {
		Demo d = new Demo();
		d.display();
	}
}
