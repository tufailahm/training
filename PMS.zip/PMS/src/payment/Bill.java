package payment;

public class Bill {
		public void payBill() {
			System.out.println("Please pay the bill of INR 9800");
		}
}
