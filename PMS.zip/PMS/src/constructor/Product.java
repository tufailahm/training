package constructor;

//constructor chaining - this

public class Product {
	int productId;
	String productName;
	int quantityOnHand;
	int price;

	public Product() {
		productId = 1001;
		productName = "NA";
		quantityOnHand = 100;
		price = 99;
	}

	public Product(int productId, String productName, int quantityOnHand, int price) {
		this.productId = productId;
		this.productName = productName;
		this.quantityOnHand = quantityOnHand;
		this.price = price;
	}

	public Product(int productId, String productName, int quantityOnHand) {
		this();
		this.productId = productId;
		this.productName = productName;
		this.quantityOnHand = quantityOnHand;
		
	}

	public Product(String productName, int productId, int price) {
		this();
		this.productName = productName;
		this.productId = productId;
		this.price = price;
	}
	

	public Product(int productId, int quantityOnHand, int price) {
		this();
		this.productId = productId;
		this.quantityOnHand = quantityOnHand;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", quantityOnHand=" + quantityOnHand
				+ ", price=" + price + "]";
	}

	public static void main(String[] args) {

		Product product1 = new Product(1,"Lakme",900,78);
		System.out.println(product1);
		Product product2 = new Product("Aroma",2,800);
		System.out.println(product2);
		Product product3 = new Product(3, "Sunscreen",200);
		System.out.println(product3);
		Product product4 = new Product(4,200,88);
		System.out.println(product4);
	}

}
