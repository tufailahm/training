package constructor;


public class Patient {

	int patientId;
	
	//default cons
	
	public Patient() {
		patientId=1001;
	}
	public Patient(int patientId) {
		this.patientId = patientId;
	}
	
	public static void main(String[] args) {
		Patient patient1 = new Patient();
		Patient patient2 = new Patient(12);

	}


}
