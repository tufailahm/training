package constructor;

public class Employee {

	int empId;
	String empName;
	
	//default cons
	public Employee() {
		empId=999;
		empName="NA";
		System.out.println("Employee cons called - 1");
	}
	
	public Employee(int empId,String empName) {
		this.empId=empId;
		this.empName=empName;
		System.out.println("Employee cons called - 2");
	}

	public void display() {
		System.out.println("Emp Id : "+empId);
		System.out.println("Emp Name : "+empName);
	}

	public static void main(String[] args) {
		Employee e1 = new Employee(12,"Mohan");
		Employee e2 = new Employee();

		e1.display();
		e2.display();
	}
}
