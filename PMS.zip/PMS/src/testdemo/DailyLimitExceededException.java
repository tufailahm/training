package testdemo;

public class DailyLimitExceededException extends Exception {

	public DailyLimitExceededException() {
		// TODO Auto-generated constructor stub
	}
	public DailyLimitExceededException(String msg) {
		super(msg);
	}
}
