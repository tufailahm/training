
package testdemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ArithemeticOperation {

	public int addNumbers(int num1, int num2, int num3) {

		// logic to add
		return num1 + num2 + num3;
	}

	public static void main(String[] args) {
		int marks[]= new int[5];
		System.out.println("Welcome");
		try {
			System.out.println(marks[2]);
			int result = 100 / 0; // ArithmeticException
			System.out.println("TRY END");
		} 
	
		catch (ArithmeticException e) 
		{
			System.out.println("Cannot divide by zero");
		}
		catch (ArrayIndexOutOfBoundsException e) 
		{
			System.out.println("Cannot access an array beyond its range");
		}
		catch (Exception e) 
		{
			System.out.println("Some other exception");
		}
		finally
		{
			//closing statement
			System.out.println("####FINALLY CALLED");
		}
		
		FileInputStream fileInputStream=null;
		try {
			 fileInputStream = new FileInputStream("d:\\study.txt");
		} catch (FileNotFoundException e) {
			System.out.println("FIle is not there -study.txt ");
		}
		finally {
			
		}
		
		//JDK1.7 - try with resources
		try (FileInputStream fs1 = new FileInputStream("d:\\code.txt")) {
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Thanks");
	}
}
