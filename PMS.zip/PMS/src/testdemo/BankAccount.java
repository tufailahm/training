package testdemo;

//throw	- raise the exception
public class BankAccount {

	//throws	- delegate the exception
	public void withdraw(int amount) throws InvalidAmountException, DailyLimitExceededException{
		if (amount < 0)
			throw new InvalidAmountException("You cannot withdraw negative amount");
		else if (amount >5000)
			throw new DailyLimitExceededException("You cannot withdraw more than 5000 in day");
		System.out.println("Successfully withdrawan : INR " + amount);

	}

	public void deposit(int amount)  throws InvalidAmountException,DailyLimitExceededException{
		if (amount < 0)
			throw new InvalidAmountException("You cannot deposit negative amount");
		else if (amount >5000)
			throw new DailyLimitExceededException("You cannot deposit more than 5000 in day");
		System.out.println("Successfully Deposited : INR " + amount);
	}

	public static void main(String[] args) {
		System.out.println("Welcome");
		BankAccount d = new BankAccount();
	
			try {
				d.deposit(5000);
				d.withdraw(8000);

			} catch (InvalidAmountException | DailyLimitExceededException e) {
				
				System.out.println(e.getMessage());
			}
		
		System.out.println("Thanks for using Banking App");
	}
}
