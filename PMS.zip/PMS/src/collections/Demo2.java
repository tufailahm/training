package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Demo2 {

	public static void main(String[] args) {

		List<Integer> marks = new ArrayList<Integer>();

		marks.add(19);
		marks.add(20);
		marks.add(19);
		marks.add(20);
		marks.add(12);

		// code to print all the marks one by one whose
		// has scored more than 15
		// ??
		Iterator<Integer> i = marks.iterator();
		while (i.hasNext()) {
			Integer temp = i.next();
			{
				if (temp > 15)
					System.out.println(temp);
			}
		}

	}
}
