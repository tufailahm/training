package collections;

public class Product implements Comparable<Product> {
	// all the properties must always be private
	private int productId;
	private String productName;
	private int quantityOnHand;
	private int price;
	
	@Override
	public int compareTo(Product o) {

		if (o.getPrice() > this.getPrice())
			return 1;
		else
			return -1;
	}

	public Product() {

	}

	public Product(int productId, String productName, int quantityOnHand, int price) {
		this.productId = productId;
		this.productName = productName;
		this.quantityOnHand = quantityOnHand;
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantityOnHand() {
		return quantityOnHand;
	}

	public void setQuantityOnHand(int quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getProductId() {
		return productId;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", quantityOnHand=" + quantityOnHand
				+ ", price=" + price + "]";
	}

	

}
