package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class ArrayListStoringObject {
	public static void main(String[] args) {

		Product product1 = new Product(1,"Lakme",19,900);
		
		
		
		System.out.println(product1.getPrice());
		product1.setPrice(999);
	
		
		List<Product> products = new ArrayList<Product>();
		
		products.add(product1);
		products.add(new Product(2, "Aroma", 500, 699));
		products.add(new Product(3, "Sunscreen", 1, 23));
		products.add(new Product(4, "Olay", 33, 55));
		products.add(new Product(5, "FairAndhandsome", 23, 33));

		

		Iterator<Product> iterator = products.iterator();
		System.out.println("Initial product data : ");
		while(iterator.hasNext())
		{
			
			Product temp = iterator.next();
			System.out.println(temp);
		}
		
		//Sort by price
		Collections.sort(products);
		System.out.println("1. After sorting by price - Comparable");
		Iterator<Product> iterator1 = products.iterator();
		while(iterator1.hasNext())
		{
			
			Product temp = iterator1.next();
			System.out.println(temp);
		}
		
		
		//Sort by QOH
		Collections.sort(products , new QOHComprator());
		System.out.println("2. After sorting by QOH - Comparator");
		Iterator<Product> iterator2 = products.iterator();
		while(iterator2.hasNext())
		{
			
			Product temp = iterator2.next();
			System.out.println(temp);
		}
		
		//Sort by Name using anonymous inner classes
		Collections.sort(products , new Comparator<Product>() {

			@Override
			public int compare(Product o1, Product o2) {
				
				if( o1.getProductName().compareTo(o2.getProductName()) > 0)
				return 1;
				else
					return -1;
			}
		});
		System.out.println("3. After sorting by NAME - Anonymous inner classes");
		Iterator<Product> iterator3 = products.iterator();
		while(iterator3.hasNext())
		{
			
			Product temp = iterator3.next();
			System.out.println(temp);
		}
		
		
	}
}
