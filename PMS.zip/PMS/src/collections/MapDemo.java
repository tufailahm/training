package collections;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/*
 * Key -Value
 * empId	 -name
 * playerId		-name
 * songId		-artistName
 */
public class MapDemo {

	public static void main(String[] args) {
		
		Map<Integer,String> empDetails = new TreeMap<Integer,String>();
		
		empDetails.put(4, "Tufail");
		empDetails.put(2, "Ahmed");
		empDetails.put(3, "Ravi");
		empDetails.put(1, "Rohan");
		
		
		//1
		for (Map.Entry<Integer,String> data : empDetails.entrySet()) {
				System.out.println(data.getKey() +  "   " + data.getValue());
		}
		
		//2
		for(Integer empId: empDetails.keySet()) {
				System.out.println(empId);
		}
		
		
		for(String empName: empDetails.values()) {
			System.out.println(empName);
	}
		
		//3
		Iterator<Map.Entry<Integer,String>> datas = empDetails.entrySet().iterator();
		
		while(datas.hasNext()) {
			System.out.println(datas.next());
		}
	}

}
