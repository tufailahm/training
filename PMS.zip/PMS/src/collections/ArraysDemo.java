	package collections;
	
	import java.util.Arrays;
	import java.util.List;
	
	public class ArraysDemo {
	
		public static void main(String[] args) {
			
			List products = Arrays.asList( new Product(1, "Lakme", 11, 12));
			
			
			System.out.println(products);
		}
	}
