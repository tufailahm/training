package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Demo {

	public static void main(String[] args) {
		List<String> s = new LinkedList<String>();
		s.add("Neha");
		s.add("Rahul");
		s.add("Mohan");
		s.add("Pooja");
		s.add("Arun");
		s.add("Pooja");

		s.remove("Mohan");
		s.add(2, "Ahmed");
		s.add("Kalpana");

		System.out.println(s.contains("Rahul"));

		System.out.println(s);

		Iterator<String> iterator = s.iterator();

		while (iterator.hasNext()) {
			String temp = iterator.next();
		//	if (temp.startsWith("P"))
				System.out.println(temp);
		}

	}
}
