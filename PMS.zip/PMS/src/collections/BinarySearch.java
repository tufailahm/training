package collections;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class BinarySearch {

	public static void main(String[] args) {
		List<String> names = new LinkedList<String>();
		names.add("Neha");
		names.add("Rahul");
		names.add("Mohan");
		names.add("Pooja");
		names.add("Arun");
		names.add("Ravi");
		
		Collections.sort(names);
		
		System.out.println(names);
		
		int result = Collections.binarySearch(names, "Pooja");

		System.out.println(result);
		

	}
}
