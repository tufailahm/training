package pack1;

public class A {
		 public int num=100;
		
		public void display() {
			
			A a = new A ();
			System.out.println(a.num);
			System.out.println(num);
		}
		public static void main(String[] args) {
			
		}
}
