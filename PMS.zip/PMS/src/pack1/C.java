package pack1;

public class C extends A {

	public static void main(String[] args) {
		
	}
	public void display() {
		A a = new A();
		System.out.println(a.num);
	}
}
