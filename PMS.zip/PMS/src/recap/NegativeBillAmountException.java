package recap;

public class NegativeBillAmountException extends Exception {
	public NegativeBillAmountException() {
		// TODO Auto-generated constructor stub
	}
	public NegativeBillAmountException(String str) {
		super(str);
	}
}
