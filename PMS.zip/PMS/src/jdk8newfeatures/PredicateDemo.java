package jdk8newfeatures;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		List<Integer> marks = new ArrayList<Integer>();
		
		marks.add(19);
		marks.add(23);
		marks.add(98);
		marks.add(13);
		marks.add(88);
		
		//Use case : 
		System.out.println("Cleared the test -- ");
		checkNumbers(marks, condition -> condition > 50);
		System.out.println("Cleared the test -- with distinction");
		checkNumbers(marks, condition -> condition >90 );
		System.out.println("Ask to reappear for the test");
		checkNumbers(marks, condition -> condition <50 );
	}
	
	public static void checkNumbers(List<Integer> marks , Predicate<Integer> predicate)
	{
			for(Integer m:marks) {
				if(predicate.test(m))
				{
					System.out.println(m);
				}
			}
	}
} 
