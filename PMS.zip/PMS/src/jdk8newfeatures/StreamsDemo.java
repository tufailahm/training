package jdk8newfeatures;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

//A stream is a sequence of elements which supports different kind of operations like filter, 
public class StreamsDemo {

	public static void main(String[] args) {
		
		// filter - P
		// sorted
		//Uppercase
		//print
		
		List<String> names = new LinkedList<String>();
		names.add("NehaJ");
		names.add("Rahul");
		names.add("Mohan");
		names.add("Pooja");
		names.add("Arun");
		names.add("Piyush");
		names.add("Pawan");
		names.add("Ravi");
		
		
		List<String> filteredList = names.stream()
		.filter(n -> n.startsWith("P"))
		.map(String::toUpperCase)
		.sorted()
		 .collect(Collectors.toList());
		//.forEach(System.out::println);
		
		
		List<String> fl=names.stream()
				.filter(n-> n.startsWith("N"))
				.map(String::toUpperCase)
				.sorted()
				.filter(m->m.endsWith("J"))
				.collect(Collectors.toList());
				System.out.println(fl);

				
		
		System.out.println(fl);
		
	}
}
