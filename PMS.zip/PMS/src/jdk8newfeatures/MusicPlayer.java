package jdk8newfeatures;

public interface MusicPlayer {
		void play();
		default void shuffle()
		{
			System.out.println("Song is Shuffled");
		}
		static void playViaUSB() {
			
		}
}
