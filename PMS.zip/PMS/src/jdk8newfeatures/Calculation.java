package jdk8newfeatures;

@FunctionalInterface
public interface Calculation {
		int addNumbers(int num1,int num2);
}
