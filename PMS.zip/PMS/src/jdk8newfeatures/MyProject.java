package jdk8newfeatures;

public class MyProject {

	public static void main(String[] args) {
		
		Calculation c = new Calculation() {
			
			@Override
			public int addNumbers(int num1, int num2) {
				
				return num1+num2;
			}
		};
		
		System.out.println(c.addNumbers(12, 12));
		
		
		//optional type decla with implicit return
		Calculation c1 = (a,b) -> a+b;
		System.out.println(c1.addNumbers(36, 36));
		
		//optional type decla
		Calculation c2 = (int a,int b) -> a+b;
		System.out.println(c2.addNumbers(36, 36));
		
		//optional type decla
		Calculation c3 = (int a,int b) -> { return a+b; };
		System.out.println(c3.addNumbers(36, 36));
	}
}
