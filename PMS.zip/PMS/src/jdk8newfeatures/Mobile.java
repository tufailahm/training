package jdk8newfeatures;

public class Mobile implements MusicPlayer {

	@Override
	public void play() {
		System.out.println("Music player started");

	}

	
	public static void main(String[] args) {
		
		Mobile m = new Mobile();
		m.play();
		m.shuffle();
	}
}
