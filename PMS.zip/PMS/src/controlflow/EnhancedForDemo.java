package controlflow;

import java.util.Scanner;

/*
 * Enhanced for loop
 * switch
 * loops
 * for
 * while
 * do_while
 * enhanced for loop
 */
/*
 *  Hands-on : WAP to use enhanced for loop to add five numbers
 *  Enter five numbers :
 *  12
 *  12
 *  12
 *  12
 *  12
 *  
 *  Result : 60
 */
public class EnhancedForDemo {

	public void display() {
			String names[] = {"Ravi","Ketan" , "Lekha", "Ahmed", "David", "Harish"};
			
			System.out.println("1. by using normal for loop");
			for(int i=0; i <6; i++) {
				System.out.println(names[i]);
			}
			
			System.out.println("2. by using normal for loop - using length");
			for(int i=0; i < names.length ; i++) {
				System.out.println(names[i]);
			}
			
			System.out.println("3. by using normal enhanced for loop");
			for(String temp:names) {
				System.out.println(temp);
			}
	}
	public static void main(String[] args) {
		EnhancedForDemo d = new EnhancedForDemo();
		d.display();
	}
}
