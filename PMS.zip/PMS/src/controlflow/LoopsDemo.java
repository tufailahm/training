package controlflow;

import java.util.Scanner;

/*
 * if else
 * switch
 * loops
 * for
 * while
 * do_while
 * enhanced for loop
 */
/*
 *  Hands-on : WAP to accept three numbers and print the largest number 
 */
public class LoopsDemo {

	int scores=0;
	public void display() {
		
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("Enter your score :");
			scores = sc.nextInt();
			if (scores > 80)
				System.out.println("Cleared the test");
			else if (scores > 50)
				System.out.println("Your choice to take the re test");
			else
				System.out.println("You have to take the re test");
			
			System.out.println("Do you want to continue : ? (Y-0 or any number to exit) ");
			int choice = sc.nextInt();
			if(choice==0)
			{
				
			}
			else
			{
				System.out.println("##Thanks for using my app");
				System.exit(0);
			}
		} while (true);
	}
	public static void main(String[] args) {
		LoopsDemo d = new LoopsDemo();
		d.display();
	}
}
