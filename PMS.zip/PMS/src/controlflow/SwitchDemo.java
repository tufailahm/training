package controlflow;
/*
 * if else
 * switch
 * loops
 * for
 * while
 * do_while
 * enhanced for loop
 */
/*
 *  Hands-on : WAP to accept DOB 
 *  Example :
 *  Enter day : 16
 *  Enter month : 4
 *  Enter year : 1995
 *   
 *   1990-1995	- You are early 90's born
 *    1995-2000	- You are late 90's born
 *     2001-2010	- You are new decade born
 *      2010-2021- You are recently born
 *      Invalid Year 
 */
public class SwitchDemo {

	int weekday=2;
	public void display() {
	switch (weekday) {
	case 1:
			System.out.println("Monday");
		break;
	case 2:
		System.out.println("Tuesday");
	break;
	case 3:
		System.out.println("Wednesday");
	break;
	default:
		System.out.println("Not a valid day");
		break;
	}
	}
	public static void main(String[] args) {
		SwitchDemo d = new SwitchDemo();
		d.display();
	}
}
