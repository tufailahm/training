package controlflow;

import java.util.Scanner;

/*
 * if else
 * switch
 * loops
 * for
 * while
 * do_while
 * enhanced for loop
 */
/*
 *  Hands-on : WAP to accept three numbers and print the largest number 
 */
public class IfDemo {

	int scores=0;
	public void display() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your score :");
		scores = sc.nextInt();
		
		if(scores>80)
			System.out.println("Cleared the test");
		else if( scores > 50)
			System.out.println("Your choice to take the re test");
		else
			System.out.println("You have to take the re test");
	}
	public static void main(String[] args) {
		IfDemo d = new IfDemo();
		d.display();
	}
}
