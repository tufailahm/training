package arraydemo;

public class Employee {

	public void display(String names[]) {
		for (String temp : names) {
			System.out.println(temp);
		}
	}

	public void display() {
		System.out.println("Employee display called");
	}

	//method overloading
	public int addNumbers(int num1, int num2) {
		System.out.println("add numbers - 1");
		return num1 + num2;
	}

	public int addNumbers(int num1, int num2,int num3) {
		System.out.println("add numbers - 2");

		return num1 + num2 + num3;
	}
	
	public void addNumbers(int...numbers) {
		System.out.println("add numbers - var args");
	}
	
	public void addScores(int sub1,int sub2, int...subjects) {
		int sum=0;
		sum = sub1+ sub2;
		for(int i:subjects) {
			sum += i;
		}
		System.out.println("You have scored : "+ sum);
	}
}
