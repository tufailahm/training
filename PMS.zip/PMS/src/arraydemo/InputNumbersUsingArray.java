package arraydemo;

import java.util.Scanner;

public class InputNumbersUsingArray {
		int marks[] = new int[5];
		
		public void accept() {
			Scanner sc = new Scanner(System.in);
			
			for (int i = 0; i < marks.length; i++) {
				System.out.println("Please enter number -  : "+ (i+1));
				
				marks[i] = sc.nextInt();
			}
			
			System.out.println("All the numbers entered by you : ");
			
			for (int j = 0; j < marks.length; j++) {
				System.out.println(marks[j]);
			}
			
		}
		public static void main(String[] args) {
			InputNumbersUsingArray obj = new InputNumbersUsingArray();
			obj.accept();
		}
}
