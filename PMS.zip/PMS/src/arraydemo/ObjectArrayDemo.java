package arraydemo;

//Array of objects
public class ObjectArrayDemo {

	public static void main(String[] args) {
		
		Employee employee[] = new Employee[5];
		
		for (int i = 0; i < employee.length; i++) {
			employee[i] = new Employee();
		}
		
		
		String empName[] = {"Tufail","Amit","Tahil"};
		employee[2].display(empName);
		
		employee[2].addNumbers(12, 12,88);
		
		employee[2].addNumbers();
		employee[2].addNumbers(12,99);
		employee[2].addNumbers(1,1,1,1);

		employee[2].addScores(12,15);
	}
}
