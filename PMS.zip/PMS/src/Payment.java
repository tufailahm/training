
public class Payment {
		public void paymentOptions() {
			System.out.println("Payment options for you");
		}
}
