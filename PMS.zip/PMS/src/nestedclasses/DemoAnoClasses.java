package nestedclasses;

abstract class Animal{
	abstract void eat();
}
public class DemoAnoClasses {

	public static void main(String[] args) {
		Animal a = new Animal() {
			
			@Override
			void eat() {
				System.out.println("Tiger eats meat");
				
			}
		};
		
		a.eat();
	}
}
