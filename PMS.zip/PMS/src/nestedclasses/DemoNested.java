package nestedclasses;

interface Music {
	void play();
}

class ChangePassword {

	String password;
	static int passwordExpired = 12;

	// inner classes
	public class EncyrptPassword {
		public void ePassword() {
			password = "some@123";

			System.out.println("Password is :" + password);
			System.out.println("Password Expired is :" + passwordExpired);
		}
	}

	// static inner classes
	static class HashingTechnique {

	}

	public void readPassword() {
		// local class
		class Pwd {

		}
	}
}

public class DemoNested {

	public static void main(String[] args) {
		ChangePassword p = new ChangePassword();

		ChangePassword.EncyrptPassword encyrptPassword = p.new EncyrptPassword();
		encyrptPassword.ePassword();

		Music m = new Music() 
		//anonymous classes in java
				{

			@Override
			public void play() {
				System.out.println("sound and music comes");

			}

		};
		
		m.play();
	}
}
