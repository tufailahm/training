package stringdemo;

public class Demo {

	public static void main(String[] args) {
		String str1 = "Revature";
		System.out.println(str1);			//Revature
		str1 = "Chennai";
		System.out.println(str1);			//Chennai
		str1.concat("Bangalore");
		System.out.println(str1);			//Chennai
		
		String str2 = str1 + " Ahmed";
		System.out.println(str2);
		
		System.out.println(str2.equalsIgnoreCase(str1));
		System.out.println(str1.substring(3, 6));
		
		
		String name1="Ahmed";
		String name2=new String("Ahmed");
		
		
		System.out.println(name1.equals(name2));		//true
		System.out.println(name1 == name2);             //true
	}
}
