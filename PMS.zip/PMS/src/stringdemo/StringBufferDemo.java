package stringdemo;

//StringBuffer Capacity
public class StringBufferDemo {

	public static void main(String[] args) {
		StringBuilder str1= new StringBuilder("Ahmed");
		
		
		str1.append(" Bangalore");
		
		System.out.println(str1.capacity());		//16		16		21
		System.out.println(str1.length());			//14		15		15
		
		str1.append("pppppp");
		
		System.out.println(str1.capacity());		//16		16		21
		System.out.println(str1.length());			//14		15		21
		
		str1.append("h");
		
		System.out.println(str1.capacity());		//16		16		44
		System.out.println(str1.length());			//14		15		22
		
		
	}
}
