package testdemo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ArithemeticOperationTest {

	ArithemeticOperation arithemeticOperation;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass");

	}

	@Before
	public void setUp() throws Exception {
		System.out.println("setUp");
		arithemeticOperation = new ArithemeticOperation();
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("tearDown");
		arithemeticOperation = null;
	}

	@Test
	public void testAddNumbers1() {
		int acutalResult = arithemeticOperation.addNumbers(12, 12, 12);
		int expectedResult = 36;
		assertEquals(expectedResult, acutalResult);
	}

	@Test
	public void testAddNumbers2() {
		int acutalResult = arithemeticOperation.addNumbers(2, 3, -10);
		int expectedResult = -5;
		assertEquals(expectedResult, acutalResult);
	}

}
