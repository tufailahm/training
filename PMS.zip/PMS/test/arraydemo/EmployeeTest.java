package arraydemo;

// extends java.lang.Object
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {

	Employee employee = new Employee();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		employee = new Employee();
	}

	@After
	public void tearDown() throws Exception {
		employee = null;
	}

	@Test
	public void testAddScores() {
			
	}

}
