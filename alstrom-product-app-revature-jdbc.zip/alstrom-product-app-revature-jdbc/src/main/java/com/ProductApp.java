package com;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.revature.pms.dao.ProductDAO;
import com.revature.pms.dao.ProductDAOImpl;
import com.revature.pms.model.Product;
import org.apache.log4j.*; 
//Logging
//Testing
public class ProductApp {

	int choice = 0;
	Scanner sc = new Scanner(System.in);
	ProductDAO productDAO = new ProductDAOImpl();
	boolean result;
	Product product = new Product();
	int productId;
	private static Logger logger = Logger.getLogger("ProductApp");

	public void startProductApp() {

		System.out.println("Please enter your name : ");
		String username = sc.next();
		
		logger.info("Welcome , "+username + " you logged in at : "+new Date());
		System.out.println("Welcome , "+username);
		while (true) {
			System.out.println("#######M E N U#######");
			System.out.println("1.Add Product ");
			System.out.println("2.Delete Product ");
			System.out.println("3.Update Product ");
			System.out.println("4.Find Product By Id");
			System.out.println("5.Find Product By Name");
			System.out.println("6.View All Products");
			System.out.println("9.E X I T ");

			System.out.println("Enter your choice : ");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				logger.info("Starting adding a product");
				System.out.println("Wecome to add product section , please enter product enter details to  save##");
				product = acceptProductDetails();
				if (productDAO.isProductExists(product.getProductId())) {
					logger.error("Product with product id : " + product.getProductId() + " already  exists");
				} else {
					logger.debug("Product added");
					result = productDAO.addProduct(product);
					if (result)
						logger.info(
								"#Product with product name : " + product.getProductName() + " , saved successfully");
					else
						logger.info("#Product with product name : " + product.getProductName()
								+ ", not saved successfully");
				}
				break;
			case 2:
				System.out.println("Please enter product id to delete : ");
				productId = sc.nextInt();
				
				if(productDAO.isProductExists(productId))
				{
					boolean resproduct = productDAO.deleteProduct(productId);
					System.out.println(resproduct + " deleted successfully :"+productId);
				}
				else
				{
					System.out.println("Product with product id :"+productId + " does not exists");
				}
				break;
			case 3:
				System.out
						.println("Wecome to update product section , please enter product enter details to  update ##");
				product = acceptProductDetails();
				result = productDAO.updateProduct(product);
				if (result)
					System.out.println(
							"#Product with product name : " + product.getProductName() + " , updated successfully");
				else
					System.out.println(
							"#Product with product name : " + product.getProductName() + ", not updated successfully");

				break;
			case 4:
				System.out.println("Please enter product id : ");
				productId = sc.nextInt();
				
				if(productDAO.isProductExists(productId))
				{
					product = productDAO.getProductById(productId);
					System.out.println();
				}
				else
				{
					System.out.println("Product with product id :"+productId + " does not exists");
				}
				break;
			case 5:
				break;
			case 6:

				List<Product> products = productDAO.getAllProducts();
				System.out.println("###Printing all the products");
				System.out.println(products);
				break;
			case 9:
				System.out.println("##Thanks for using my product app");
				System.exit(0);
				break;
			}
		}
	}

	public Product acceptProductDetails() {
		System.out.println("Please enter product id : ");
		int productId = sc.nextInt();
		System.out.println("Please enter product name : ");
		String productName = sc.next();
		System.out.println("Please enter quantity on Hand: ");
		int quantityOnHand = sc.nextInt();
		System.out.println("Please enter price : ");
		int price = sc.nextInt();
		System.out.println("Please enter comments: ");
		String comments = sc.next();

		Product product = new Product(productId, productName, quantityOnHand, price, comments);
		return product;
	}
}
