package com.revature.pms.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.revature.pms.model.Product;

public class ProductDAOImplTest {

	private ProductDAO productDAO;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		productDAO = new ProductDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		productDAO = null;
	}

	@Test
	public void testAddProduct() {
		// Testing adding a product
		int productIdToTest = -999;

		// Adding a dummy product to test Product addedProduct = new
		Product addedProduct = new Product(productIdToTest, "DemoProduct", 6, 6, "Good");
		productDAO.addProduct(addedProduct);

		// Retrieving the product to test Product retrievedProduct =
		Product retrievedProduct = productDAO.getProductById(-999);

		assertEquals( addedProduct, retrievedProduct);

		// deleting the product after testing
		productDAO.deleteProduct(productIdToTest);
	}

	@Test
	public void testDeleteProduct() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateProduct() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetProductById() { 
		// Testing getting a single
		int productIdToTest = -999;

		// Adding a dummy product to test Product addedProduct = new
		Product addedProduct = new Product(productIdToTest, "DemoProduct", 6, 6, "Good");
		productDAO.addProduct(addedProduct);

		// Retrieving the product to test Product retrievedProduct =
		productDAO.getProductById(-999);

		// testing assertEquals( addedProduct, retrievedProduct);

		// deleting the product after testing
		productDAO.deleteProduct(productIdToTest);
	}

	@Test
	public void testGetProductByName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllProducts() {
		// Testing getting all products;
		int productIdToTest = -999;
		List<Product> originalProducts1 = productDAO.getAllProducts();
		productDAO.addProduct(new Product(productIdToTest, "DemoProduct", 6, 6, "Good"));
		List<Product> originalProducts2 = productDAO.getAllProducts();

		assertEquals(originalProducts2.size(), originalProducts1.size() + 1);

		productDAO.deleteProduct(productIdToTest);
	}

	@Test
	public void testIsProductExists() {
		fail("Not yet implemented");
	}

}
