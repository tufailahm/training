package com.ahmed.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFormValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFormValidationApplication.class, args);
	}
}
