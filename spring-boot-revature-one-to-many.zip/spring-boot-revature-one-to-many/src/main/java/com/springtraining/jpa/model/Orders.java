package com.springtraining.jpa.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Orders implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
    private String itemname;
    private Customer customer;

    public Orders(int id, String itemname, Customer customer) {
		super();
		this.id = id;
		this.itemname = itemname;
		this.customer = customer;
	}

    
	public Orders(String itemname, Customer customer) {
		super();
		this.itemname = itemname;
		this.customer = customer;
	}


	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   public void setItemname(String itemname) {
	this.itemname = itemname;
}
   
   
  public String getItemname() {
	return itemname;
}
    @ManyToOne
    @JoinColumn(name = "customer_id")
 public Customer getCustomer() {
	return customer;
}
    
    public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
