package com.springtraining.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springtraining.jpa.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	@Query(value = "SELECT c.name,o.itemname FROM Customer c inner join c.orders o where c.id = ?1")
	public List<Object[]> methodThatQueriesMultipleTables(int customerId);
}