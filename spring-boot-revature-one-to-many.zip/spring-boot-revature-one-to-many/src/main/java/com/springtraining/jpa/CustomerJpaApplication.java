package com.springtraining.jpa;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.springtraining.jpa.model.Customer;
import com.springtraining.jpa.model.Orders;
import com.springtraining.jpa.repository.CustomerRepository;
/* In DBweaver
 * drop table customer;
drop table orders;

select * from customer;
select * from orders;
and then run this app
 */
@SpringBootApplication
public class CustomerJpaApplication implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(CustomerJpaApplication.class);

    @Autowired
    private CustomerRepository customerRepository;

    public static void main(String[] args) {
        SpringApplication.run(CustomerJpaApplication.class, args);
    }

    @Transactional
    public void run(String... strings) throws Exception {
        // save a couple of categories
        final Customer customer = new Customer("Tufail"); 
        
        Set<Orders> orders1 = new HashSet<Orders>(){
		{
            add(new Orders("Mouse", customer));
            add(new Orders("Lakme", customer));
            add(new Orders("Aroma", customer));
        }};
        customer.setOrders(orders1);

final Customer customer2 = new Customer("Rohit"); 
        
        Set orders2 = new HashSet<Orders>(){{
            add(new Orders("Mouse", customer2));
            add(new Orders("HP", customer2));
            add(new Orders("Pendrive", customer2));
        }};
        customer2.setOrders(orders2);

        customerRepository.saveAll(new HashSet<Customer>() 
        		{{
            add(customer);
            add(customer2);
        }});

       //Displaying all the results by join..
        System.out.println("\n####Displaying all the results by join..");
        
List<Object[]> list = customerRepository.methodThatQueriesMultipleTables(49);
        
        for (Object object : list) {
            Object[] li = (Object[])object;
            for(Object liItem:li){
                
            	System.out.println(liItem);
             if (liItem instanceof Customer) {
                System.out.println(((Customer)liItem).getName());        
             }else {
               // System.out.println(((Orders) liItem).getItemname());   
             }
                
            }
        }
        
        
		/*
		 * List allRec = customerRepository.methodThatQueriesMultipleTables(); Iterator
		 * iterator = allRec.iterator(); while(iterator.hasNext()) { Customer rows =
		 * (Customer)iterator.next();
		 * System.out.println("Customer Name : "+rows.getName());
		 * 
		 * 
		 * Set s= rows.getOrders(); Iterator it1=s.iterator();
		 * 
		 * while(it1.hasNext()) { Orders c = (Orders) it1.next();
		 * System.out.println(c.getItemname());
		 * 
		 * } }
		 */
        
        System.out.println("\n\n#############################");
    }
}
