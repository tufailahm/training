package com.revature.pms.model;

public class Employee {
		
}
