package com.revature.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.revature.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {

	private static Logger logger = Logger.getLogger("ProductDAOImpl");

	Configuration configuration = new Configuration().configure();		//hibernate.cfg.xml
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();
	
	
	// THis will add product in DB
	public boolean addProduct(Product product) {
		Transaction transaction = session.beginTransaction();
		session.save(product);
		transaction.commit();
		return true;
	}

	public boolean deleteProduct(int productId) {
		return false;

	}

	public boolean updateProduct(Product product) {
		return (Boolean) null;
	}

	public Product getProductById(int productId) {
		return null;
	}

	// To do
	public List<Product> getProductByName(String productName) {
		return null;
	}

	public List<Product> getAllProducts() {
		return null;
	}

	public boolean isProductExists(int productId) {

		return (Boolean) null;
	}

}
