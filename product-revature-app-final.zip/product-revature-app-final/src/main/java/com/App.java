package com;

/**
 * Tufail Product App Main
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("#########Tufail's Product App");
		ProductApp productApp = new ProductApp();
		productApp.startProductApp();
	}
}
