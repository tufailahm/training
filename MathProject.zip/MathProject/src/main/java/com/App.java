package com;

import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.*;

public class App 
{
	private Logger logger = Logger.getLogger(App.class);
	
	Scanner sc = new Scanner(System.in);
	int num1,num2,result=0;
	public void addNumbers() {
		
		logger.info("Add numbers method started executing at time :"+new Date());
		System.out.println("Enter first number :");
		num1 = sc.nextInt();
		if(num1<0)
		{
			logger.error("Num1 cannot be negative");
		}
		if(num1>100)
		{
			logger.fatal("Num1 cannot be more than 100");
		}
		System.out.println("Enter second number :");
		num2 = sc.nextInt();
		
		result = num1 + num2;
		if(result>1000)
		{
			logger.warn("result is more than 1000, please check");
		}
		System.out.println("The result is :"+result);
		
		logger.info("Method completed successfully with the result :"+result);
	}
    public static void main( String[] args )
    {
        App a = new App();
        a.addNumbers();
    }
}
