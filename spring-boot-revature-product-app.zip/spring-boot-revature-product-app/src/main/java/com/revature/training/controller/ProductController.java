package com.revature.training.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.training.pms.model.Product;

@RestController
@RequestMapping("product")
public class ProductController {
	@GetMapping
	public List<Product> getProducts() {
		System.out.println("All products called");
		return null;
	}

	@GetMapping("{productId}")
	public List<Product> getProduct(@PathVariable("productId") int pId) {
		System.out.println("getting a  single called : " + pId);
		// hit the service layer to get the product with product id 987
		return null;
	}

	@GetMapping("/searchByProductName/{productName}")
	public List<Product> getProductByName(@PathVariable("productName") String productName) {
		System.out.println("getting a  single product by product name : " + productName);
		// hit the service layer to get the product with product id 987
		return null;
	}

	@PostMapping
	public String addProduct(@RequestBody Product product) {
		System.out.println("add products called");
		System.out.println(product);
		return null;
	}

	@PutMapping
	public String updateProduct(@RequestBody Product product) {
		System.out.println("update products called");
		System.out.println(product);
		return null;
	}
	// Putmapping

	@DeleteMapping("{productId}")
	public String deleteProduct(@PathVariable("productId") int pId) {
		System.out.println("deleteing product called by id : " + pId);
		return null;
	}
	// Delete mapping
}
