export class Product {
    productId?: number;
    productName?: string;
    quantityOnHand?: number;
    price?: number;
}
