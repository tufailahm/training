package com.revature.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {

	@RequestMapping("/emp")
	public ModelAndView getEmp() {
		ModelAndView view = new ModelAndView();
		view.setViewName("employee");
		return view;
	}
}
